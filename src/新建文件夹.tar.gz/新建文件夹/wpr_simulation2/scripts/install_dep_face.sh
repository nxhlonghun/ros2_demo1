#!/bin/bash
yes | pip3 install face_recognition -i https://pypi.tuna.tsinghua.edu.cn/simple